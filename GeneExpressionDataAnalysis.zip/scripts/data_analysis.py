import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA

# Load the preprocessed data
df = pd.read_csv('../data/preprocessed_gene_expression_data.csv')

# Perform PCA
pca = PCA(n_components=2)
pca_result = pca.fit_transform(df.iloc[:, 1:])
df['PCA1'] = pca_result[:, 0]
df['PCA2'] = pca_result[:, 1]

# Plot PCA results
plt.figure(figsize=(16, 10))
sns.scatterplot(x='PCA1', y='PCA2', hue=df.columns[0], data=df, palette='viridis')
plt.title('PCA of Gene Expression Data')
plt.savefig('../reports/pca_gene_expression.png')
plt.close()

# Save analysis results
pca.explained_variance_ratio_.tofile('../reports/pca_variance_ratio.txt', sep=',')
