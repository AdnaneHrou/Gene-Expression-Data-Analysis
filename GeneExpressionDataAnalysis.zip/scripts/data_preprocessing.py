import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

# Load the dataset
df = pd.read_csv('../data/gene_expression_data.csv')

# Preprocess the data
def preprocess_data(df):
    # Log transform the expression data
    df.iloc[:, 1:] = np.log1p(df.iloc[:, 1:])

    # Standardize the data
    scaler = StandardScaler()
    df.iloc[:, 1:] = scaler.fit_transform(df.iloc[:, 1:])
    return df

if __name__ == '__main__':
    df = preprocess_data(df)
    df.to_csv('../data/preprocessed_gene_expression_data.csv', index=False)
